package me.mattis.prefix.chat;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import me.mattis.prefix.main.Main;

public class Chat implements Listener {

	@EventHandler
	public void onChat(AsyncPlayerChatEvent e) {
		
		Player p = e.getPlayer();
		
		String R1 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R2 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R3 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R4 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R5 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R6 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R7 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R8 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R9 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R10 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R11 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R12 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R13 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R14 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		String R15 = Main.getPlugin().getConfig().getString("Plugin.Prefix.Prefix1.Chat").replaceAll("&", "�").replaceAll(">>", "�").replaceAll("**", "�").replace("{player}", ""+p.getName()+"").replace("{message}", ""+e.getMessage()+"");
		
		if (p.hasPermission("rang.1")) {
			e.setFormat(R1);
		} else if (p.hasPermission("rang.2")) {
			e.setFormat(R2);
		} else if (p.hasPermission("rang.3")) {
			e.setFormat(R3);
		} else if (p.hasPermission("rang.4")) {
			e.setFormat(R4);
		} else if (p.hasPermission("rang.5")) {
			e.setFormat(R5);
		} else if (p.hasPermission("rang.6")) {
			e.setFormat(R6);
		} else if (p.hasPermission("rang.7")) {
			e.setFormat(R7);
		} else if (p.hasPermission("rang.8")) {
			e.setFormat(R8);
		} else if (p.hasPermission("rang.9")) {
			e.setFormat(R9);
		} else if (p.hasPermission("rang.10")) {
			e.setFormat(R10);
		} else if (p.hasPermission("rang.11")) {
			e.setFormat(R11);
		} else if (p.hasPermission("rang.12")) {
			e.setFormat(R12);
		} else if (p.hasPermission("rang.13")) {
			e.setFormat(R13);
		} else if (p.hasPermission("rang.14")) {
			e.setFormat(R14);
		} else
			e.setFormat(R15);
		
	}
	
}
