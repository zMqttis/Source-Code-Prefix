package me.mattis.prefix.main;

import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;

import me.mattis.prefix.chat.Chat;

public class Main extends JavaPlugin implements Listener {
	
	private static Main plugin;
	
	Scoreboard sb;
	
	@Override
	public void onEnable() {
		
		plugin = this;
		
		loadConfig();
		
		ConsoleCommandSender c = Bukkit.getConsoleSender();
		
		c.sendMessage("�ePrefix �7| �aDas Plugin wurde geladen!");
		c.sendMessage("�ePrefix �7| �aThe Plugin is loadet!");
		
		sb = Bukkit.getScoreboardManager().getNewScoreboard();
		
		Bukkit.getPluginManager().registerEvents(new Chat(), this);
		Bukkit.getPluginManager().registerEvents(this, this);
		
		String T1 = getConfig().getString("Plugin.Prefix.Prefix1.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T2 = getConfig().getString("Plugin.Prefix.Prefix2.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T3 = getConfig().getString("Plugin.Prefix.Prefix3.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T4 = getConfig().getString("Plugin.Prefix.Prefix4.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T5 = getConfig().getString("Plugin.Prefix.Prefix5.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T6 = getConfig().getString("Plugin.Prefix.Prefix6.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T7 = getConfig().getString("Plugin.Prefix.Prefix7.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T8 = getConfig().getString("Plugin.Prefix.Prefix8.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T9 = getConfig().getString("Plugin.Prefix.Prefix9.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T10 = getConfig().getString("Plugin.Prefix.Prefix10.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T11 = getConfig().getString("Plugin.Prefix.Prefix11.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T12 = getConfig().getString("Plugin.Prefix.Prefix12.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T13 = getConfig().getString("Plugin.Prefix.Prefix13.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T14 = getConfig().getString("Plugin.Prefix.Prefix14.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		String T15 = getConfig().getString("Plugin.Prefix.Prefix15.Tablist").replaceAll("&", "�").replaceAll(">>", "�");
		
		sb.registerNewTeam("00000Rang");
		sb.registerNewTeam("00001Rang");
		sb.registerNewTeam("00002Rang");
		sb.registerNewTeam("00003Rang");
		sb.registerNewTeam("00004Rang");
		sb.registerNewTeam("00005Rang");
		sb.registerNewTeam("00006Rang");
		sb.registerNewTeam("00007Rang");
		sb.registerNewTeam("00008Rang");
		sb.registerNewTeam("00009Rang");
		sb.registerNewTeam("000010Rang");
		sb.registerNewTeam("000011Rang");
		sb.registerNewTeam("000012Rang");
		sb.registerNewTeam("000013Rang");
		sb.registerNewTeam("000014Rang");
		
		sb.getTeam("00000Rang").setPrefix(T1);
		sb.getTeam("00001Rang").setPrefix(T2);
		sb.getTeam("00002Rang").setPrefix(T3);
		sb.getTeam("00003Rang").setPrefix(T4);
		sb.getTeam("00004Rang").setPrefix(T5);
		sb.getTeam("00005Rang").setPrefix(T6);
		sb.getTeam("00006Rang").setPrefix(T7);
		sb.getTeam("00007Rang").setPrefix(T8);
		sb.getTeam("00008Rang").setPrefix(T9);
		sb.getTeam("00009Rang").setPrefix(T10);
		sb.getTeam("000010Rang").setPrefix(T11);
		sb.getTeam("000011Rang").setPrefix(T12);
		sb.getTeam("000012Rang").setPrefix(T13);
		sb.getTeam("000013Rang").setPrefix(T14);
		sb.getTeam("000014Rang").setPrefix(T15);
		
	}

	private void loadConfig() {
		
		reloadConfig();
		
		getConfig().addDefault("Plugin.Prefix.Prefix1.Chat", "&fRang1 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix2.Chat", "&fRang2 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix3.Chat", "&fRang3 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix4.Chat", "&fRang4 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix5.Chat", "&fRang5 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix6.Chat", "&fRang6 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix7.Chat", "&fRang7 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix8.Chat", "&fRang8 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix9.Chat", "&fRang9 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix10.Chat", "&fRang10 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix11.Chat", "&fRang11 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix12.Chat", "&fRang12 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix13.Chat", "&fRang13 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix14.Chat", "&fRang14 &8** &f{player} &8| &f{message}");
		getConfig().addDefault("Plugin.Prefix.Prefix15.Chat", "&fRang15 &8** &f{player} &8| &f{message}");
		
		getConfig().addDefault("Plugin.Prefix.Prefix1.Tablist", "&fRang1 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix2.Tablist", "&fRang2 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix3.Tablist", "&fRang3 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix4.Tablist", "&fRang4 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix5.Tablist", "&fRang5 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix6.Tablist", "&fRang6 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix7.Tablist", "&fRang7 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix8.Tablist", "&fRang8 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix9.Tablist", "&fRang9 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix10.Tablist", "&fRang10 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix11.Tablist", "&fRang11 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix12.Tablist", "&fRang12 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix13.Tablist", "&fRang13 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix14.Tablist", "&fRang14 &8** &f");
		getConfig().addDefault("Plugin.Prefix.Prefix15.Tablist", "&fRang15 &8** &f");
		
		getConfig().addDefault("Plugin.Prefix.Prefix1.Permission", "rang.1");
		getConfig().addDefault("Plugin.Prefix.Prefix2.Permission", "rang.2");
		getConfig().addDefault("Plugin.Prefix.Prefix3.Permission", "rang.3");
		getConfig().addDefault("Plugin.Prefix.Prefix4.Permission", "rang.4");
		getConfig().addDefault("Plugin.Prefix.Prefix5.Permission", "rang.5");
		getConfig().addDefault("Plugin.Prefix.Prefix6.Permission", "rang.6");
		getConfig().addDefault("Plugin.Prefix.Prefix7.Permission", "rang.7");
		getConfig().addDefault("Plugin.Prefix.Prefix8.Permission", "rang.8");
		getConfig().addDefault("Plugin.Prefix.Prefix9.Permission", "rang.9");
		getConfig().addDefault("Plugin.Prefix.Prefix10.Permission", "rang.10");
		getConfig().addDefault("Plugin.Prefix.Prefix11.Permission", "rang.11");
		getConfig().addDefault("Plugin.Prefix.Prefix12.Permission", "rang.12");
		getConfig().addDefault("Plugin.Prefix.Prefix13.Permission", "rang.13");
		getConfig().addDefault("Plugin.Prefix.Prefix14.Permission", "rang.14");
		getConfig().addDefault("Plugin.Prefix.Prefix15.Permission", "rang.15");
		
		getConfig().options().copyDefaults(true);
		saveConfig();
	}
	
	public static Main getPlugin() {
		return plugin;
		
	}
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		setPrefix(e.getPlayer());
		try {
			
		} catch (Exception e1) {
			
		}
	}

	private void setPrefix(Player p) {
		
		String team = "";
		
		if (p.hasPermission("rang.1")) {
			team = "00000Rang";
		} else if (p.hasPermission("rang.2")) {
			team = "00001Rang";
		} else if (p.hasPermission("rang.3")) {
			team = "00002Rang";
		} else if (p.hasPermission("rang.4")) {
			team = "00003Rang";
		} else if (p.hasPermission("rang.5")) {
			team = "00004Rang";
		} else if (p.hasPermission("rang.6")) {
			team = "00005Rang";
		} else if (p.hasPermission("rang.7")) {
			team = "00006Rang";
		} else if (p.hasPermission("rang.8")) {
			team = "00007Rang";
		} else if (p.hasPermission("rang.9")) {
			team = "00008Rang";
		} else if (p.hasPermission("rang.10")) {
			team = "00009Rang";
		} else if (p.hasPermission("rang.11")) {
			team = "000010Rang";
		} else if (p.hasPermission("rang.12")) {
			team = "000011Rang";
		} else if (p.hasPermission("rang.13")) {
			team = "000012Rang";
		} else if (p.hasPermission("rang.14")) {
			team = "000013Rang";
		} else
			team = "000014Rang";
		
		sb.getTeam(team).addPlayer(p);
		p.setDisplayName(sb.getTeam(team).getPrefix());
		
		for (Player all : Bukkit.getOnlinePlayers()){
			all.setScoreboard(sb);
		}
		
	}

}
